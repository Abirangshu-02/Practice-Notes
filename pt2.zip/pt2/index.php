<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HOME</title>
</head>
    <frameset cols="25%,75%">
        <frame src="register.php">
        <frame src="login.php">
    </frameset>
</html>